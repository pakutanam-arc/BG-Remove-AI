import React, { useState, useRef } from 'react';
import { UploadCloud, Image as ImageIcon } from 'lucide-react';

interface FileUploaderProps {
  onFileSelect?: (file: File) => void;
  onFilesSelect?: (files: File[]) => void;
  accept?: string;
  maxSizeMB?: number;
  multiple?: boolean;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ 
  onFileSelect, 
  onFilesSelect,
  accept = 'image/jpeg, image/png, image/webp', 
  maxSizeMB = 10,
  multiple = false
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = (filesList: FileList | File[]) => {
    setError(null);
    const validFiles: File[] = [];
    
    for (let i = 0; i < filesList.length; i++) {
      const file = filesList[i];
      if (!file.type.startsWith('image/')) {
        setError('Format file tidak didukung. Harap unggah gambar.');
        return;
      }
      if (file.size > maxSizeMB * 1024 * 1024) {
        setError(`Ukuran file terlalu besar. Maksimal ${maxSizeMB}MB per file.`);
        return;
      }
      validFiles.push(file);
      
      if (!multiple) break; // Only take first file if not multiple
    }

    if (validFiles.length > 0) {
      if (multiple && onFilesSelect) {
        onFilesSelect(validFiles);
      } else if (onFileSelect) {
        onFileSelect(validFiles[0]);
      }
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => {
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  return (
    <div className="w-full flex flex-col items-center">
      <div
        className={`w-full max-w-2xl p-12 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center transition-colors cursor-pointer ${
          isDragging 
            ? 'border-[#6366F1] bg-indigo-50 dark:bg-[#1A1A1E]' 
            : 'border-zinc-300 dark:border-[#27272A] hover:border-zinc-400 dark:hover:border-[#3f3f46] bg-zinc-50 dark:bg-[#0F0F11]'
        }`}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <UploadCloud className={`w-12 h-12 mb-4 transition-colors ${isDragging ? 'text-[#6366F1]' : 'text-zinc-400 dark:text-[#71717A]'}`} />
        <p className="text-lg font-medium text-zinc-900 dark:text-[#F4F4F5] mb-1">
          Tarik & Lepas gambar di sini
        </p>
        <p className="text-sm text-zinc-500 dark:text-[#71717A]">
          atau klik untuk memilih file (JPG, PNG, WebP hingga {maxSizeMB}MB) {multiple && '(Bisa pilih banyak sekaligus)'}
        </p>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept={accept}
          multiple={multiple}
          onChange={(e) => {
            if (e.target.files && e.target.files.length > 0) {
              handleFiles(e.target.files);
            }
          }}
        />
      </div>
      {error && (
        <p className="mt-4 text-[#F43F5E] text-sm font-medium">{error}</p>
      )}
    </div>
  );
};

