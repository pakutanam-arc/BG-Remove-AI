import React, { useState, useRef } from 'react';
import { ChevronsLeftRight } from 'lucide-react';

interface ImageComparisonProps {
  originalUrl: string;
  resultUrl: string;
}

export const ImageComparison: React.FC<ImageComparisonProps> = ({ originalUrl, resultUrl }) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    let clientX = 0;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
    } else {
      clientX = e.clientX;
    }
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    setSliderPosition((x / rect.width) * 100);
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full max-w-3xl aspect-[4/3] rounded-xl overflow-hidden cursor-ew-resize select-none border border-zinc-200 dark:border-[#27272A] shadow-xl dark:shadow-[0_40px_100px_rgba(0,0,0,0.5)] checkerboard-bg"
      onMouseMove={handleMouseMove}
      onTouchMove={handleMouseMove}
    >
      {/* Result Image (Background) */}
      <img 
        src={resultUrl} 
        alt="Result" 
        className="absolute top-0 left-0 w-full h-full object-contain pointer-events-none" 
      />
      
      {/* Original Image (Clipped) */}
      <div 
        className="absolute top-0 left-0 w-full h-full overflow-hidden"
        style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
      >
        <img 
          src={originalUrl} 
          alt="Original" 
          className="absolute top-0 left-0 w-full h-full object-contain pointer-events-none"
        />
      </div>

      {/* Slider Handle */}
      <div 
        className="absolute top-0 bottom-0 w-[2px] bg-[#6366F1] cursor-ew-resize"
        style={{ left: `calc(${sliderPosition}% - 1px)` }}
      >
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-9 h-9 bg-[#6366F1] rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(99,102,241,0.5)] border-2 border-white">
          <ChevronsLeftRight className="w-5 h-5 text-white" />
        </div>
      </div>
    </div>
  );
};
