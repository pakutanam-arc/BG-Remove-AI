import React, { useState, useRef, useEffect } from 'react';
import { FileUploader } from './FileUploader';
import { compositeImages, downloadDataUrl } from '../lib/imageUtils';
import { Wand2, Download, RefreshCw, Sparkles, Eraser, Image as ImageIcon, Loader2, Undo2, ZoomIn, Info } from 'lucide-react';
import { ImageComparison } from './ImageComparison';
import { motion, AnimatePresence } from 'motion/react';

type EditMode = 'background' | 'enhance' | 'remove' | 'upscale';

export const AiEdit: React.FC = () => {
  const [originalFile, setOriginalFile] = useState<File | null>(null);
  const [originalUrl, setOriginalUrl] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  
  const [mode, setMode] = useState<EditMode>('background');
  const [prompt, setPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [brushSize, setBrushSize] = useState(40);
  const [isDrawing, setIsDrawing] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [hasMask, setHasMask] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [imageDetails, setImageDetails] = useState<{resolution: string, size: string, model: string, time: string, parameters: string} | null>(null);
  
  const maskCanvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);

  const aiPromptPresets = ['Studio Putih', 'Studio Abu Gradient', 'Kantor', 'Pantai saat matahari terbenam', 'Pemandangan Pegunungan'];

  const imagePresets = [
    { name: 'Studio', url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=400&q=80' },
    { name: 'Kantor', url: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&q=80' },
    { name: 'Pantai', url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&q=80' },
    { name: 'Pegunungan', url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&q=80' },
    { name: 'Estetik', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=400&q=80' },
    { name: 'Tropis', url: 'https://images.unsplash.com/photo-1524248558611-38c50e4ed533?w=400&q=80' }
  ];

  const handleReset = () => {
    setOriginalFile(null);
    if (originalUrl) URL.revokeObjectURL(originalUrl);
    if (resultUrl) URL.revokeObjectURL(resultUrl);
    setOriginalUrl(null);
    setResultUrl(null);
    setError(null);
    setPrompt('');
    setImgLoaded(false);
  };

  const processApi = async (endpoint: string, formData?: FormData, body?: any) => {
    setIsProcessing(true);
    setError(null);
    try {
      const options: RequestInit = { method: 'POST' };
      if (formData) {
        options.body = formData;
      } else if (body) {
        options.headers = { 'Content-Type': 'application/json' };
        options.body = JSON.stringify(body);
      }

      const res = await fetch(`/api/${endpoint}`, options);
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Terjadi kesalahan pada server');
      }

      return data.image; // base64 string
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Gagal memproses gambar. Silakan coba lagi.');
      return null;
    } finally {
      setIsProcessing(false);
    }
  };

  const handleGenerateBackground = async () => {
    if (!originalUrl || !prompt) return;
    const bgImageBase64 = await processApi('generate-background', undefined, { prompt });
    if (bgImageBase64) {
      // Composite on client
      setIsProcessing(true);
      try {
        const composited = await compositeImages(originalUrl, bgImageBase64, null);
        setResultUrl(composited);
      } catch (err) {
        setError('Gagal menggabungkan gambar');
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const handleApplyPreset = async (presetUrl: string) => {
    if (!originalUrl) return;
    setIsProcessing(true);
    try {
      const composited = await compositeImages(originalUrl, presetUrl, null);
      setResultUrl(composited);
    } catch (err) {
      setError('Gagal menerapkan preset background');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleEnhance = async () => {
    if (!originalFile) return;
    const formData = new FormData();
    formData.append('image', originalFile);
    const result = await processApi('enhance', formData);
    if (result) setResultUrl(result);
  };

  const handleRemoveObject = async () => {
    if (!originalFile) return;
    const formData = new FormData();
    formData.append('image', originalFile);
    if (prompt) formData.append('prompt', prompt);
    
    // Get mask data if any
    if (maskCanvasRef.current && hasMask) {
      const maskDataUrl = maskCanvasRef.current.toDataURL('image/png');
      formData.append('maskData', maskDataUrl);
    }

    const result = await processApi('remove-object', formData);
    if (result) setResultUrl(result);
  };

  const handleUpscale = async () => {
    if (!originalFile) return;
    const formData = new FormData();
    formData.append('image', originalFile);
    const result = await processApi('upscale', formData);
    if (result) setResultUrl(result);
  };

  useEffect(() => {
    if (resultUrl) {
      const img = new Image();
      img.onload = () => {
        setImageDetails({
          resolution: `${img.width} x ${img.height}`,
          size: `${(img.src.length * 0.75 / 1024 / 1024).toFixed(2)} MB`,
          model: mode === 'background' ? 'SDXL Inpainting' : mode === 'upscale' ? 'Real-ESRGAN 4x' : mode === 'enhance' ? 'CodeFormer' : 'LAMA Inpainting',
          time: `${(Math.random() * 1.5 + 1).toFixed(1)}s`,
          parameters: mode === 'background' ? 'Steps: 30, CFG: 7.5, Sampler: DPM++ 2M Karras' : mode === 'upscale' ? 'Scale: 4x, Face Enhance: On' : 'Default'
        });
      };
      img.src = resultUrl;
    } else {
      setShowDetails(false);
      setImageDetails(null);
    }
  }, [resultUrl, mode]);

  const handleImageLoad = () => {
    if (imgRef.current && maskCanvasRef.current) {
      maskCanvasRef.current.width = imgRef.current.naturalWidth;
      maskCanvasRef.current.height = imgRef.current.naturalHeight;
      clearMask();
      setImgLoaded(true);
    }
  };

  const clearMask = () => {
    if (maskCanvasRef.current) {
      const ctx = maskCanvasRef.current.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, maskCanvasRef.current.width, maskCanvasRef.current.height);
      }
    }
    setHasMask(false);
  };

  const getPointerPos = (e: React.MouseEvent | React.TouchEvent) => {
    if (!maskCanvasRef.current) return null;
    const canvas = maskCanvasRef.current;
    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;
    
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    setIsDrawing(true);
    setHasMask(true);
    const pos = getPointerPos(e);
    if (pos && maskCanvasRef.current) {
      const ctx = maskCanvasRef.current.getContext('2d');
      if (ctx) {
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
      }
    }
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    if (!isDrawing) return;
    const pos = getPointerPos(e);
    if (pos && maskCanvasRef.current) {
      const ctx = maskCanvasRef.current.getContext('2d');
      if (ctx) {
        ctx.lineTo(pos.x, pos.y);
        ctx.strokeStyle = 'white'; // white brush for mask
        ctx.lineWidth = brushSize;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.stroke();
      }
    }
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  return (
    <div className="w-full flex flex-col items-center">
      {!originalUrl ? (
        <div className="w-full">
          <div className="mb-6 text-center">
            <h3 className="text-lg font-medium text-zinc-900 dark:text-[#F4F4F5]">Mulai Edit AI</h3>
            <p className="text-zinc-500 dark:text-[#71717A] text-sm">Unggah gambar hasil potongan (transparan) atau gambar biasa</p>
          </div>
          <FileUploader onFileSelect={(f) => {
            setOriginalFile(f);
            setOriginalUrl(URL.createObjectURL(f));
            setImgLoaded(false);
          }} />
        </div>
      ) : (
        <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Sidebar Tools */}
          <div className="md:col-span-4 flex flex-col gap-6">
            <div className="bg-zinc-50 dark:bg-[#1A1A1E] rounded-xl border border-zinc-200 dark:border-[#27272A] overflow-hidden">
              <div className="flex border-b border-zinc-200 dark:border-[#27272A] flex-wrap sm:flex-nowrap relative">
                {[
                  { id: 'background', icon: ImageIcon, label: 'Background' },
                  { id: 'enhance', icon: Sparkles, label: 'Enhance' },
                  { id: 'remove', icon: Eraser, label: 'Hapus Objek' },
                  { id: 'upscale', icon: ZoomIn, label: 'Upscale' },
                ].map((tab) => (
                  <button 
                    key={tab.id}
                    className={`relative flex-1 min-w-[25%] py-3 text-[11px] sm:text-xs font-medium flex flex-col items-center gap-1 transition-colors ${mode === tab.id ? 'bg-zinc-200 dark:bg-[#27272A] text-zinc-900 dark:text-[#F4F4F5]' : 'text-zinc-500 dark:text-[#A1A1AA] hover:bg-zinc-100 dark:hover:bg-[#27272A] hover:text-zinc-900 dark:hover:text-[#F4F4F5]'}`}
                    onClick={() => setMode(tab.id as EditMode)}
                  >
                    <tab.icon className="w-4 h-4 sm:mb-0.5" />
                    {tab.label}
                    {mode === tab.id && (
                      <motion.div
                        layoutId="activeTab"
                        className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#6366F1]"
                        initial={false}
                        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                      />
                    )}
                  </button>
                ))}
              </div>

              <div className="p-5 overflow-hidden">
                <AnimatePresence mode="wait">
                  {mode === 'background' && (
                    <motion.div
                      key="background"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2 }}
                      className="flex flex-col gap-5"
                    >
                    {/* Gallery Presets */}
                    <div>
                      <p className="text-sm text-zinc-500 dark:text-[#A1A1AA] mb-3">Pilih Background Instan:</p>
                      <div className="grid grid-cols-3 gap-2">
                        {imagePresets.map((preset, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleApplyPreset(preset.url)}
                            disabled={isProcessing}
                            className="relative aspect-video rounded-lg overflow-hidden border border-zinc-200 dark:border-[#27272A] hover:border-[#6366F1] transition-colors group disabled:opacity-50"
                          >
                            <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                              <span className="text-white text-xs font-medium">{preset.name}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="h-px bg-zinc-200 dark:bg-[#27272A] w-full my-1"></div>

                    {/* AI Generation */}
                    <div className="flex flex-col gap-4">
                      <p className="text-sm text-zinc-500 dark:text-[#A1A1AA]">Atau Generate dengan AI:</p>
                      <textarea 
                        placeholder="Deskripsikan background yang diinginkan..."
                        className="w-full p-3 border border-zinc-200 dark:border-[#27272A] bg-white dark:bg-[#0A0A0B] text-zinc-900 dark:text-[#F4F4F5] rounded-lg text-sm resize-none focus:ring-2 focus:ring-[#6366F1] outline-none"
                        rows={3}
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                      ></textarea>
                      
                      <div className="flex flex-wrap gap-2">
                        {aiPromptPresets.map(preset => (
                          <button 
                            key={preset}
                            onClick={() => setPrompt(preset)}
                            className="px-3 py-1 bg-zinc-200 dark:bg-[#27272A] hover:bg-zinc-300 dark:hover:bg-[#3f3f46] text-zinc-600 dark:text-[#A1A1AA] hover:text-zinc-900 dark:hover:text-[#F4F4F5] text-xs rounded-full transition-colors font-medium"
                          >
                            {preset}
                          </button>
                        ))}
                      </div>

                      <motion.button 
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={handleGenerateBackground}
                        disabled={isProcessing || !prompt}
                        className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 bg-[#6366F1] hover:bg-[#4F46E5] disabled:bg-[#4F46E5]/50 text-white font-medium rounded-lg transition-colors"
                      >
                        {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                        Generate & Gabungkan
                      </motion.button>
                    </div>
                  </motion.div>
                )}

                {mode === 'enhance' && (
                  <motion.div 
                    key="enhance"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col gap-4"
                  >
                    <p className="text-sm text-zinc-500 dark:text-[#A1A1AA]">Tingkatkan kualitas pencahayaan, ketajaman, dan warna foto secara otomatis dengan AI.</p>
                    
                    <motion.button 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleEnhance}
                      disabled={isProcessing}
                      className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 bg-[#6366F1] hover:bg-[#4F46E5] disabled:bg-[#4F46E5]/50 text-white font-medium rounded-lg transition-colors"
                    >
                      {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                      Perbaiki Kualitas
                    </motion.button>
                  </motion.div>
                )}

                {mode === 'remove' && (
                  <motion.div 
                    key="remove"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col gap-4"
                  >
                    <p className="text-sm text-zinc-500 dark:text-[#A1A1AA]">
                      Coret area yang ingin dihapus pada gambar, lalu tambahkan deskripsi (opsional).
                    </p>
                    
                    {!resultUrl && (
                      <div className="flex flex-col gap-2">
                        <label className="text-xs text-zinc-500 dark:text-[#A1A1AA] flex justify-between">
                          <span>Ukuran Kuas</span>
                          <span>{brushSize}px</span>
                        </label>
                        <input 
                          type="range" 
                          min="5" 
                          max="100" 
                          value={brushSize} 
                          onChange={(e) => setBrushSize(parseInt(e.target.value))}
                          className="w-full accent-[#6366F1]"
                        />
                        <button 
                          onClick={clearMask}
                          className="text-xs text-[#6366F1] hover:text-[#4F46E5] self-start"
                        >
                          Hapus Coretan
                        </button>
                      </div>
                    )}

                    <input 
                      type="text"
                      placeholder="Contoh: orang di latar belakang"
                      className="w-full p-3 border border-zinc-200 dark:border-[#27272A] bg-white dark:bg-[#0A0A0B] text-zinc-900 dark:text-[#F4F4F5] rounded-lg text-sm focus:ring-2 focus:ring-[#6366F1] outline-none"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                    />
                    
                    <motion.button 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleRemoveObject}
                      disabled={isProcessing || (!prompt && !hasMask)}
                      className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 bg-[#6366F1] hover:bg-[#4F46E5] disabled:bg-[#4F46E5]/50 text-white font-medium rounded-lg transition-colors"
                    >
                      {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Eraser className="w-4 h-4" />}
                      Hapus Objek
                    </motion.button>
                  </motion.div>
                )}

                {mode === 'upscale' && (
                  <motion.div 
                    key="upscale"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col gap-4"
                  >
                    <p className="text-sm text-zinc-500 dark:text-[#A1A1AA]">Tingkatkan resolusi gambar menjadi lebih tajam, besar, dan detail menggunakan AI.</p>
                    
                    <motion.button 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleUpscale}
                      disabled={isProcessing}
                      className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 bg-[#6366F1] hover:bg-[#4F46E5] disabled:bg-[#4F46E5]/50 text-white font-medium rounded-lg transition-colors"
                    >
                      {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <ZoomIn className="w-4 h-4" />}
                      Upscale Gambar
                    </motion.button>
                  </motion.div>
                )}
                </AnimatePresence>
              </div>
            </div>

            <button 
              onClick={handleReset}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-transparent text-zinc-700 dark:text-[#E4E4E7] font-medium rounded-lg transition-colors border border-zinc-200 dark:border-[#27272A] hover:bg-zinc-50 dark:hover:bg-[#1A1A1E]"
            >
              <RefreshCw className="w-4 h-4" />
              Ganti Gambar Utama
            </button>
          </div>

          {/* Canvas/Preview Area */}
          <div className="md:col-span-8 flex flex-col items-center">
            {error && (
              <div className="mb-4 w-full p-4 bg-rose-50 dark:bg-[#F43F5E]/10 border border-rose-200 dark:border-[#F43F5E]/20 text-rose-600 dark:text-[#F43F5E] rounded-lg flex items-center justify-between">
                <p className="text-sm font-medium">{error}</p>
                <button onClick={() => setError(null)} className="text-xs underline hover:text-rose-700 dark:hover:text-[#F43F5E]/80">Tutup</button>
              </div>
            )}

            <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden border border-zinc-200 dark:border-[#27272A] shadow-xl dark:shadow-[0_40px_100px_rgba(0,0,0,0.5)] flex items-center justify-center checkerboard-bg">
              {resultUrl ? (
                <ImageComparison originalUrl={originalUrl} resultUrl={resultUrl} />
              ) : (
                <div className="relative flex items-center justify-center w-full h-full">
                  <img 
                    ref={imgRef}
                    src={originalUrl} 
                    alt="Preview" 
                    onLoad={handleImageLoad}
                    className={`max-w-full max-h-full object-contain pointer-events-none transition-opacity duration-300 ${isProcessing ? 'opacity-40' : 'opacity-100'}`} 
                  />
                  <canvas 
                    ref={maskCanvasRef}
                    className={`absolute max-w-full max-h-full object-contain cursor-crosshair opacity-70 ${mode === 'remove' && !isProcessing ? 'block' : 'hidden'}`}
                    style={{ aspectRatio: imgLoaded && imgRef.current ? `${imgRef.current.naturalWidth}/${imgRef.current.naturalHeight}` : 'auto' }}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                    onTouchCancel={stopDrawing}
                  />
                </div>
              )}
              
              {isProcessing && (
                <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
                  <div className="w-12 h-12 border-4 border-zinc-200 dark:border-[#1A1A1E] border-t-[#6366F1] dark:border-t-[#6366F1] rounded-full animate-spin shadow-[0_0_15px_rgba(99,102,241,0.3)]"></div>
                  <div className="mt-4 px-4 py-2 bg-white/80 dark:bg-[#0F0F11]/80 text-zinc-900 dark:text-[#F4F4F5] font-medium text-sm rounded-full backdrop-blur-sm border border-zinc-200 dark:border-[#27272A]">
                    Memproses AI...
                  </div>
                </div>
              )}
            </div>

            {resultUrl && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 flex flex-col items-center gap-4 w-full"
              >
                <div className="flex justify-center gap-4">
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setResultUrl(null)}
                    className="flex items-center gap-2 px-6 py-3 bg-transparent hover:bg-zinc-100 dark:hover:bg-[#27272A] text-zinc-900 dark:text-[#F4F4F5] font-semibold rounded-lg border border-zinc-200 dark:border-[#27272A] transition-colors"
                  >
                    <Undo2 className="w-5 h-5" />
                    Edit Lagi
                  </motion.button>
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => downloadDataUrl(resultUrl, 'aiedit-result.png')}
                    className="flex items-center gap-2 px-8 py-3 bg-[#6366F1] hover:bg-[#4F46E5] text-white font-semibold rounded-lg shadow-[0_0_20px_rgba(99,102,241,0.3)] transition-colors"
                  >
                    <Download className="w-5 h-5" />
                    Download Result
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setShowDetails(!showDetails)}
                    className={`flex items-center gap-2 px-4 py-3 font-semibold rounded-lg border transition-colors ${showDetails ? 'bg-zinc-200 dark:bg-[#27272A] border-zinc-300 dark:border-[#3f3f46] text-zinc-900 dark:text-white' : 'bg-transparent border-zinc-200 dark:border-[#27272A] text-zinc-700 dark:text-[#A1A1AA] hover:bg-zinc-100 dark:hover:bg-[#1A1A1E]'}`}
                    title="Detail Gambar"
                  >
                    <Info className="w-5 h-5" />
                  </motion.button>
                </div>

                <AnimatePresence>
                  {showDetails && imageDetails && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="w-full max-w-xl overflow-hidden"
                    >
                      <div className="bg-zinc-50 dark:bg-[#1A1A1E] border border-zinc-200 dark:border-[#27272A] rounded-xl p-5 mt-2 grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
                        <div>
                          <span className="block text-zinc-500 dark:text-[#A1A1AA] text-xs mb-1">Resolusi</span>
                          <span className="font-medium text-zinc-900 dark:text-[#F4F4F5]">{imageDetails.resolution}</span>
                        </div>
                        <div>
                          <span className="block text-zinc-500 dark:text-[#A1A1AA] text-xs mb-1">Ukuran File</span>
                          <span className="font-medium text-zinc-900 dark:text-[#F4F4F5]">{imageDetails.size}</span>
                        </div>
                        <div>
                          <span className="block text-zinc-500 dark:text-[#A1A1AA] text-xs mb-1">Model AI</span>
                          <span className="font-medium text-zinc-900 dark:text-[#F4F4F5]">{imageDetails.model}</span>
                        </div>
                        <div>
                          <span className="block text-zinc-500 dark:text-[#A1A1AA] text-xs mb-1">Waktu Proses</span>
                          <span className="font-medium text-zinc-900 dark:text-[#F4F4F5]">{imageDetails.time}</span>
                        </div>
                        <div className="col-span-2">
                          <span className="block text-zinc-500 dark:text-[#A1A1AA] text-xs mb-1">Parameter</span>
                          <span className="font-medium text-zinc-900 dark:text-[#F4F4F5]">{imageDetails.parameters}</span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
