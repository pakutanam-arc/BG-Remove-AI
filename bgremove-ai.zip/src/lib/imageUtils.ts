export const resizeImageFile = (file: File, maxDimension: number = 2000): Promise<File> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDimension || height > maxDimension) {
          const ratio = Math.min(maxDimension / width, maxDimension / height);
          width = width * ratio;
          height = height * ratio;
        } else {
          // No need to resize
          return resolve(file);
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return reject(new Error('Failed to get canvas context'));
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob((blob) => {
          if (!blob) return reject(new Error('Canvas to blob failed'));
          resolve(new File([blob], file.name, { type: 'image/png' }));
        }, 'image/png');
      };
      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
};

export const compositeImages = (foregroundUrl: string, backgroundUrl: string | null, backgroundColor: string | null): Promise<string> => {
  return new Promise((resolve, reject) => {
    const fgImg = new Image();
    fgImg.crossOrigin = 'anonymous';
    fgImg.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = fgImg.width;
      canvas.height = fgImg.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject(new Error('Failed to get canvas context'));

      const drawForeground = () => {
        ctx.drawImage(fgImg, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      };

      if (backgroundColor) {
        ctx.fillStyle = backgroundColor;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        drawForeground();
      } else if (backgroundUrl) {
        const bgImg = new Image();
        bgImg.crossOrigin = 'anonymous';
        bgImg.onload = () => {
          // Draw background to cover the whole canvas (center crop)
          const scale = Math.max(canvas.width / bgImg.width, canvas.height / bgImg.height);
          const x = (canvas.width / 2) - (bgImg.width / 2) * scale;
          const y = (canvas.height / 2) - (bgImg.height / 2) * scale;
          ctx.drawImage(bgImg, x, y, bgImg.width * scale, bgImg.height * scale);
          drawForeground();
        };
        bgImg.onerror = () => {
          console.warn('Failed to load background, drawing foreground only');
          drawForeground();
        };
        bgImg.src = backgroundUrl;
      } else {
        drawForeground();
      }
    };
    fgImg.onerror = () => reject(new Error('Failed to load foreground image'));
    fgImg.src = foregroundUrl;
  });
};

export const downloadDataUrl = (dataUrl: string, filename: string) => {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
