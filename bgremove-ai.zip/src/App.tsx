import React, { useState, useEffect } from 'react';
import { BackgroundRemoval } from './components/BackgroundRemoval';
import { AiEdit } from './components/AiEdit';
import { Scissors, Sparkles, Sun, Moon } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'bgremove' | 'aiedit'>('bgremove');
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(t => t === 'dark' ? 'light' : 'dark');
  };

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-[#0A0A0B] text-zinc-900 dark:text-[#F4F4F5] font-sans selection:bg-[#6366F1]/30 transition-colors">
      <header className="bg-white dark:bg-[#0F0F11] border-b border-zinc-200 dark:border-[#27272A] sticky top-0 z-10 transition-colors">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex items-center justify-center shadow-md">
              <Scissors className="w-3.5 h-3.5 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-zinc-900 dark:text-white flex items-center gap-2">
              BGRemove AI
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-zinc-100 dark:bg-[#27272A] text-zinc-500 dark:text-[#A1A1AA] font-bold tracking-wide">BETA</span>
            </h1>
          </div>
          
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg bg-zinc-100 dark:bg-[#1A1A1E] text-zinc-600 dark:text-[#A1A1AA] hover:text-zinc-900 dark:hover:text-[#F4F4F5] transition-colors"
            title="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex justify-center mb-8">
          <div className="inline-flex bg-zinc-100 dark:bg-[#1A1A1E] p-1 rounded-xl transition-colors">
            <button
              onClick={() => setActiveTab('bgremove')}
              className={`flex items-center gap-2 px-6 py-2 rounded-lg text-[13px] font-medium transition-all ${
                activeTab === 'bgremove'
                  ? 'bg-white dark:bg-[#27272A] text-zinc-900 dark:text-white shadow-sm dark:shadow-[0_1px_3px_rgba(0,0,0,0.3)]'
                  : 'text-zinc-500 dark:text-[#A1A1AA] hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <Scissors className="w-4 h-4" />
              Hapus Background
            </button>
            <button
              onClick={() => setActiveTab('aiedit')}
              className={`flex items-center gap-2 px-6 py-2 rounded-lg text-[13px] font-medium transition-all ${
                activeTab === 'aiedit'
                  ? 'bg-white dark:bg-[#27272A] text-zinc-900 dark:text-white shadow-sm dark:shadow-[0_1px_3px_rgba(0,0,0,0.3)]'
                  : 'text-zinc-500 dark:text-[#A1A1AA] hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              AI Edit
            </button>
          </div>
        </div>

        <div className="bg-white dark:bg-[#0F0F11] rounded-2xl border border-zinc-200 dark:border-[#27272A] p-6 md:p-8 min-h-[500px] transition-colors">
          {activeTab === 'bgremove' ? <BackgroundRemoval /> : <AiEdit />}
        </div>
      </main>
    </div>
  );
}
